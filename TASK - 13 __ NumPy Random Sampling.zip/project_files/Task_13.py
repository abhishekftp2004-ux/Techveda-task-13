import numpy as np

# Task 13: NumPy Random Sampling

# Random integers
np.random.seed(42)
random_integers = np.random.randint(1, 101, size=10)
print("Random integers:", random_integers)

# Random floating-point numbers
random_floats = np.random.random(10)
print("Random floats:", random_floats)

# Random values in a range
random_values = np.random.uniform(10, 50, size=5)
print("Uniform random values:", random_values)

# Random sample from an array
students = np.array(["Aman", "Priya", "Rahul", "Neha", "Karan", "Sneha", "Vikas", "Anjali"])
sample = np.random.choice(students, size=4, replace=False)
print("Random student sample:", sample)

# Simulated student marks
np.random.seed(100)
marks = np.random.randint(40, 101, size=10)
print("Simulated marks:", marks)

# Reproducibility
np.random.seed(123)
result_1 = np.random.randint(1, 50, size=5)
np.random.seed(123)
result_2 = np.random.randint(1, 50, size=5)
print("First result:", result_1)
print("Second result:", result_2)
print("Reproducible:", np.array_equal(result_1, result_2))

# Sampling with probabilities
np.random.seed(7)
categories = np.array(["Low", "Medium", "High"])
category_sample = np.random.choice(categories, size=10, p=[0.5, 0.3, 0.2])
print("Category sample:", category_sample)

print("Mean:", marks.mean())
print("Minimum:", marks.min())
print("Maximum:", marks.max())
