# Task 13: NumPy Random Sampling — Expanded Assessment

This expanded assessment explains random integers, random floating-point values, random sampling, simulated student marks, random seeds, reproducibility, probability-based sampling, common mistakes, practical applications, interview questions, and a complete Python program.

## Top 5 Skills
1. NumPy
2. Random Data Generation
3. Random Sampling
4. Reproducible Data Analysis
5. Python Data Science
